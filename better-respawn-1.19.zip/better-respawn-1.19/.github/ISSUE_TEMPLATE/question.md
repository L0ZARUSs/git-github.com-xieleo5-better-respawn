---
name: Question
about: Ask a question about this mod
title: ''
labels: question
assignees: henkelmax

---

**Make sure your question hasn't been answered in the [FAQ](https://modrepo.de/minecraft/better_respawn/faq)!**
